<?php

if ( ! defined( 'ABSPATH' ) )  
	die( 'No direct access allowed' );

function sixscan_events_uninstall() {
		
	sixscan_installation_uninstall();
}	

?>