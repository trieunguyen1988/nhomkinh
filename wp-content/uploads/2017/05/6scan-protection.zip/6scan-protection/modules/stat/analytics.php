<?php
/*	Legacy placeholder */
?>